 oa\adreader
 1qaz@WSX